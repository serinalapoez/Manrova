from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from .engine import SimulationEngine

app = FastAPI(title="Manrova Simulation Environment")
engine = SimulationEngine()
app.mount("/static", StaticFiles(directory="static"), name="static")

class SpeedRequest(BaseModel):
    multiplier: float

@app.get("/")
def index():
    return FileResponse("static/index.html")

@app.get("/api/state")
def state():
    return engine.state.public_dict()

@app.get("/api/telemetry")
def telemetry():
    return engine.telemetry()

@app.get("/api/events")
def events():
    return [e.__dict__ for e in engine.state.events[-80:]]

@app.post("/api/simulation/start")
def start():
    engine.start()
    return {"ok": True}

@app.post("/api/simulation/pause")
def pause():
    engine.pause()
    return {"ok": True}

@app.post("/api/simulation/reset")
def reset():
    engine.reset()
    return {"ok": True}

@app.post("/api/simulation/speed")
def speed(req: SpeedRequest):
    engine.set_speed(req.multiplier)
    return {"ok": True, "speed_multiplier": engine.state.speed_multiplier}

@app.post("/api/scenarios/{scenario}")
def scenario(scenario: str):
    try:
        engine.inject(scenario)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    return engine.state.public_dict()
